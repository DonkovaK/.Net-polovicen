﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Cinephile.Data.Migrations
{
    public partial class updateMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "Faves");

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "MovieInFaves",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "MovieInFaves");

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "Faves",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
