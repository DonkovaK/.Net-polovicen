﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Cinephile.Data.Migrations
{
    public partial class blogmodelup : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
