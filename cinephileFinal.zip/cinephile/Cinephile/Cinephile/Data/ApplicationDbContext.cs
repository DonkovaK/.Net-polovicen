﻿using Cinephile.Models.Domain;
using Cinephile.Models.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cinephile.Data
{
    public class ApplicationDbContext : IdentityDbContext<Cusser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Cinephile.Models.Blog.Post> Post { get; set; }
        public virtual DbSet<Movie> Movies { get; set; }
        public virtual DbSet<Fave> Faves { get; set; }
        public virtual DbSet<MovieInFave> MovieInFaves { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Movie>()
                .Property(z => z.Id)
                .ValueGeneratedOnAdd();

            builder.Entity<Fave>()
              .Property(z => z.Id)
              .ValueGeneratedOnAdd();


            builder.Entity<MovieInFave>()
                .HasKey(z => new { z.MovieId, z.FaveId });


            builder.Entity<MovieInFave>()
                .HasOne(z => z.Movie)
                .WithMany(z => z.MoviesInFaves)
                .HasForeignKey(z => z.FaveId);

            builder.Entity<MovieInFave>()
                .HasOne(z => z.Fave)
                .WithMany(z => z.MovieInFaves)
                .HasForeignKey(z => z.MovieId);

            builder.Entity<Fave>()
                .HasOne<Cusser>(z => z.Owner)
                .WithOne(z => z.UserCart)
                .HasForeignKey<Fave>(z => z.OwnerId);
        }


    }
}

   
