﻿using Cinephile.Data;
using Cinephile.Models.Domain;
using Cinephile.Models.DTO;
using Cinephile.Models.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Cinephile.Controllers
{
    public class FaveController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<Cusser> _userManager;

        public FaveController(ApplicationDbContext context, UserManager<Cusser> userManager)
        {
            _context = context;
            _userManager = userManager;

        }

        public ICollection<MovieInFave> MovieInFave { get; private set; }
        public double TotalTime { get; private set; }

        public async Task<IActionResult> IndexAsync()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier);
            var loggedInUser = await _context.Users.
                Where(z => z.Id.Equals(userId))
                        .Include(z => z.UserCart)
                        .Include(z => z.UserCart.MovieInFaves)
                .Include("UserCart.MovieInFaves.Movie")
                .FirstOrDefaultAsync();


          
           return View();
        }
    }
}