﻿using System;

namespace Cinephile.Models
{
    public class Post
    {
        internal bool isFavorite;

        public Guid? Id { get; internal set; }
        public Guid? ID { get; internal set; }
    }
}