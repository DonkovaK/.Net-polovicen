﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Domain
{
    public class Movie
    {
        public Guid Id { get; set; }
        [Required]
        public string MovieName { get; set; }
        [Required]
        public string MovieGenre { get; set; }
        [Required]
        public string MovieDescription { get; set; }
        [Required]
        public int Rating { get; set; }
        [Required]
        public int TimeDuration { get; set; }
        public virtual ICollection<MovieInFave> MoviesInFaves
        {
            get; set;
        }
    }
}