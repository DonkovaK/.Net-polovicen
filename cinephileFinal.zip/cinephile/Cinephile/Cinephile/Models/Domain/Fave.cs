﻿using Cinephile.Models.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Domain
{
    public class Fave
    {
        public Guid Id { get; set; }
        public string OwnerId { get; set; }
        public Cusser Owner { get; set; }
        public virtual ICollection<MovieInFave> MovieInFaves { get; set; }
    
    public Fave() { }
    }
}
