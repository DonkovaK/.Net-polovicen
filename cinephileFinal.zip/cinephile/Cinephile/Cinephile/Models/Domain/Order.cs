﻿using Cinephile.Models.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Domain
{
    public class Order
    {
        public Guid Id { get; set; }
        public string UserId { get; set; }
        public Cusser User { get; set; }

        public virtual ICollection<MovieInFave> MovieInFaves { get; set; }
    }
}
