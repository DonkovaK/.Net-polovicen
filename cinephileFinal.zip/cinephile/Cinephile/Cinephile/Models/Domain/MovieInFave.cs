﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Domain
{
    public class MovieInFave
    {
        public Guid MovieId { get; set; }
        public Movie Movie { get; set; }
        public Guid FaveId { get; set; }
        public int Quantity { get; set; }
        public Fave Fave { get; set; }
    }
}
