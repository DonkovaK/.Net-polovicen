﻿using Cinephile.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.DTO
{
    public class FaveDto
    {
        public List<MovieInFave> MovieInFaves { get; set; }
        public double TotalTime { get; set; }
        public ICollection<MovieInFave> MovieInFave { get; internal set; }
    }
}
