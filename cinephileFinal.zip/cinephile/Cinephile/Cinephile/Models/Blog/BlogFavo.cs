﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Blog
{
    public class BlogFavo
    {
        public Guid PostID { get; set; }
        public Post Post { get; set; }
    }
}
