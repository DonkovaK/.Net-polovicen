﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Blog
{
    public class BlogAddtoFavo
    {
        public Post SelectedPost { get; set; }
        public Guid Id { get; set; }
    }
}
