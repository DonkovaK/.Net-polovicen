﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Cinephile.Models.Blog
{
    public class Post
    {
        public IList<string> Categories { get; } = new List<string>();



        [Required]
        public string Content { get; set; } = string.Empty;

        public string PostImage { get; set; } = string.Empty;

        [Required]
        public string Excerpt { get; set; } = string.Empty;

        [Required]
        public Guid ID { get; set; }
        public bool IsPublished { get; set; } = true;

        public bool isFavorite { get; set; } = false;

        public DateTime LastModified { get; set; } = DateTime.UtcNow;

        public DateTime PubDate { get; set; } = DateTime.UtcNow;

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string Slug { get; set; } = string.Empty;

        [Required]
        public string Title { get; set; } = string.Empty;



    }
}


